package com.mycompany.app;

public class FrontendSearchRequest {
    //private String searchQueryL;
    private String searchQuery;

    public String getSearchQuery() {
        return searchQuery;
    }
}
